package com.pattern.java;

//Implementation of SecondMessageSubscriber
public class SecondMessageSubscriber implements Observer {

	@Override
	public void updateObserver(Message message) {
		System.out.println("Message for Second subscriber :: " + message.getMessage());

	}

}
