package com.pattern.java;

//Observer has to fulfill this contract
public interface Observer {
	public void updateObserver(Message message);
}
