package com.pattern.java;

/*Contract for register,unregister & 
 notifyUpdate to Observer*/
public interface Subject {

	public void register(Observer observer);

	public void unregister(Observer observer);

	public void notifyUpdate(Message message);

}
