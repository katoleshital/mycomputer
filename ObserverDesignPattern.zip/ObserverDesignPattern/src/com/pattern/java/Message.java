package com.pattern.java;

//Model class to represent message
public final class Message {
	private final String message;

	public Message(String message) {
		this.message = message;
	}

	public String getMessage() {
		return message;
	}
}
