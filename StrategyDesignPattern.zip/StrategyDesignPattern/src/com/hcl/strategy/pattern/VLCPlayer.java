package com.hcl.strategy.pattern;

public class VLCPlayer implements MediaPlayer {
	public void playFile() {
		System.out.println("playing vlc file");
	}



}
