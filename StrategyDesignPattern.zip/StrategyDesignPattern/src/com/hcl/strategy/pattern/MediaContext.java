package com.hcl.strategy.pattern;

public class MediaContext {
	
	private MediaPlayer mediaplayer;
	
	public MediaContext( MediaPlayer mediaplayer) {
		this.mediaplayer=mediaplayer;
	}
	
	public void executePlayingMediaFile() {
		mediaplayer.playFile();
		
	}

}