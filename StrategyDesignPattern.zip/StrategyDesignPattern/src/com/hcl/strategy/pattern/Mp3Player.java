package com.hcl.strategy.pattern;

public class Mp3Player implements MediaPlayer {
	public void playFile() {
		System.out.println("playing mp3 file");
	}
}
