package com.hcl.strategy.pattern;

public interface MediaPlayer {
	public void playFile();

}
