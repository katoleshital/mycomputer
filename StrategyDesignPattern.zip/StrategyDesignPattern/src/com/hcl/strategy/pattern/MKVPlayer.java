package com.hcl.strategy.pattern;

public class MKVPlayer implements  MediaPlayer{

	@Override
	public void playFile() {
		// TODO Auto-generated method stub
		System.out.println("playing mkv file");
		
	}

}
