package com.registry1.java;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Serviceregistry1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
