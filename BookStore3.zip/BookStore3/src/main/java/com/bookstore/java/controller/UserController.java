package com.bookstore.java.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bookstore.java.dto.UserRequestDto;
import com.bookstore.java.dto.UserResponseDto;
import com.bookstore.java.entity.User;
import com.bookstore.java.service.UserService;

@RestController
public class UserController {

	@Autowired
	private UserService userService;

	/*
	 * @PostMapping("/users") public ResponseEntity<UserResponseDto>
	 * login(@RequestBody UserRequestDto userRequestDto) { UserResponseDto response
	 * = userService.login(userRequestDto); return new
	 * ResponseEntity<UserResponseDto>(response, HttpStatus.ACCEPTED);
	 * 
	 * }
	 */

	@PostMapping("/users")
	public String registration(@RequestBody User user) {
		userService.registerUser(user);
		return "user registered Successfully";
	}

	@GetMapping("/users/userlogin")
	@PreAuthorize("hasRole('ROLE_USER')")
	public String userLogin(Principal principal) {
		return "user login successfully";
	}

	/*
	 * @PostMapping("/users") public ResponseEntity<UserResponseDto>
	 * login(@RequestBody UserRequestDto userRequestDto) { UserResponseDto response
	 * = userService.login(userRequestDto); return new
	 * ResponseEntity<UserResponseDto>(response, HttpStatus.ACCEPTED);
	 * 
	 */

}
