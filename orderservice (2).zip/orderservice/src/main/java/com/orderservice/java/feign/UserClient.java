package com.orderservice.java.feign;

import org.springframework.cloud.openfeign.FeignClient;

@FeignClient("USERSERVICE")
public interface UserClient {
	
	

}
