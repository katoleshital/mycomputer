package com.orderservice.java.service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.orderservice.java.dto.OrderRequestDto;
import com.orderservice.java.dto.OrderResponseDto;
import com.orderservice.java.entity.OrderDetails;
import com.orderservice.java.exception.OrderNotFoundException;
import com.orderservice.java.repo.OrderRepo;

@Service
public class OrderService implements IOrderService {
	@Autowired
	OrderRepo orderRepo;

	@Override
	public String saveOrder(OrderRequestDto orderRequestDto) {

		OrderDetails orderDetails = new OrderDetails();
		orderDetails.setDate(LocalDate.now());
		orderDetails.setTime(LocalTime.now());
		BeanUtils.copyProperties(orderRequestDto, orderDetails);
		OrderDetails savedUser = orderRepo.save(orderDetails);
		if (savedUser != null)
			return "order data saved successfully";
		return "order data save was unsuccessfull";
	}

	@Override
	public List<OrderResponseDto> getAllOrderDetails() {
		  if (orderRepo.findAllOrders().isEmpty())
	            throw new OrderNotFoundException ("order not found");
	        return orderRepo.findAllOrders();
	 
	}

	@Override
	public List<OrderDetails> findPaginated(int pageNo, int pageSize) {
		Pageable paging = PageRequest.of(pageNo, pageSize);
		Page<OrderDetails> pagedResult = orderRepo.findAll(paging);
		return pagedResult.toList();
	}

}
