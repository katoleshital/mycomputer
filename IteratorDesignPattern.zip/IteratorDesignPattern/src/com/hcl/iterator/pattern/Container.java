package com.hcl.iterator.pattern;

public interface Container {
	public MyIterator getMyIterator();

}
