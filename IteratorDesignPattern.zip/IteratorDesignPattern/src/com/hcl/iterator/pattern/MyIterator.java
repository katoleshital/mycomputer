package com.hcl.iterator.pattern;

public interface MyIterator {
	public boolean hasNext();

	public Object next();

}
