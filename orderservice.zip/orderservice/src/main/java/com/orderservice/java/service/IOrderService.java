package com.orderservice.java.service;

import java.util.List;

import com.orderservice.java.dto.OrderRequestDto;
import com.orderservice.java.dto.OrderResponseDto;
import com.orderservice.java.entity.OrderDetails;

public interface IOrderService {

	// void saveOrderDetails(OrderRequestDto orderRequestDto);
	String saveOrder(OrderRequestDto orderRequestDto);

	List<OrderResponseDto> getAllOrderDetails();

	List<OrderDetails> findPaginated(int pageNo, int pageSize);

}
