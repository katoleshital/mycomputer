package com.userservice.java.service;

import javax.validation.Valid;

import com.userservice.java.entity.User;

public interface UserService {

	void registerUser(User user);

	String getRoleByUserId(@Valid Integer userId);

	User getUserByUserId(@Valid Integer userId);

}
