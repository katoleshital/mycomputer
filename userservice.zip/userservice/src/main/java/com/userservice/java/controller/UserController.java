package com.userservice.java.controller;

import java.security.Principal;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.userservice.java.entity.User;
import com.userservice.java.service.UserService;

@RestController
public class UserController {

	@Autowired
	UserService userService;

	@GetMapping("/users/userlogin")
	@PreAuthorize("hasRole('ROLE_TRAINER')")
	public String userLogin(Principal principal) {
		return "login successfully";
	}

	@PostMapping("/users")
	public String registration(@RequestBody User user) {
		userService.registerUser(user);
		return "Success";
	}

	// Api for getting user by passing userId
	@GetMapping("/users/{userId}")
	public User getUserByUserId(@Valid @PathVariable Integer userId) {
		return userService.getUserByUserId(userId);

	}

	// Api for getting role by passing userId
	@GetMapping("/users/userId")
	public ResponseEntity<String> getRoleByUserId(@Valid @RequestParam Integer userId) {
		return new ResponseEntity<String>(userService.getRoleByUserId(userId), HttpStatus.OK);

	}

}