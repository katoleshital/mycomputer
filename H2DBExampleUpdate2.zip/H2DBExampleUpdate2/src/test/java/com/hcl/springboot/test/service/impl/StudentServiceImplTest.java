package com.hcl.springboot.test.service.impl;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.BeanUtils;

import com.hcl.springboot.dto.StudentRequestDto;
import com.hcl.springboot.dto.StudentResponseDto;
import com.hcl.springboot.entity.Student;
import com.hcl.springboot.repository.IStudentRepository;
import com.hcl.springboot.service.impl.StudentServiceImpl;

@ExtendWith(MockitoExtension.class)
public class StudentServiceImplTest  {

	@Mock
	IStudentRepository studentRepository;

	@InjectMocks
	StudentServiceImpl studentServiceImpl;

	StudentRequestDto studentRequestDto;

	Student student;
	Student savedStudent;

	@BeforeEach
	public void setUp() {
		studentRequestDto = new StudentRequestDto();
		studentRequestDto.setName("Anil");
		studentRequestDto.setCourse("java");
		studentRequestDto.setDepartment("CSE");
		studentRequestDto.setEmail("anil@gmail.com");
		
		student = new Student();
		student.setName("Anil");
		student.setCourse("java");
		student.setDepartment("CSE");
		student.setEmail("anil@gmail.com");
		
		savedStudent = new Student();
		savedStudent.setName("Anil");
		savedStudent.setCourse("java");
		savedStudent.setDepartment("CSE");
		savedStudent.setEmail("anil@gmail.com");
		savedStudent.setStudentId(1);
	}

	@Test
	public void saveStudentDataTest_Positive() {
		when(studentRepository.save(any(Student.class))).thenReturn(savedStudent);

		boolean result = studentServiceImpl.saveStudentData(studentRequestDto);

		assertTrue(result);

	}
	
	@Test
	public void saveStudentDataTest_Negative() {
		
		when(studentRepository.save(any(Student.class))).thenReturn(null);

		boolean result = studentServiceImpl.saveStudentData(studentRequestDto);

		assertFalse(result);
		
	}
	@Test
	public void getStudentDetaisTest_Positive() {
		List<StudentResponseDto> studentResponseList = new ArrayList<>();
		StudentResponseDto studentResponseDto = new StudentResponseDto();
		BeanUtils.copyProperties(savedStudent, studentResponseDto);
		studentResponseList.add(savedStudent);
		when(studentRepository.findAll()).thenReturn(savedStudent);

		boolean result = studentServiceImpl.saveStudentData(studentRequestDto);

		assertFalse(result);
		
	}
	
	public List<StudentResponseDto> getStudentDetails() {
		List<StudentResponseDto> studentResponseList = new ArrayList<>();
		Iterator it = studentRepository.findAll().iterator();

		while (it.hasNext()) {
			StudentResponseDto responseDto = new StudentResponseDto();
			BeanUtils.copyProperties(it.next(), responseDto);
			studentResponseList.add(responseDto);
		}
		if(studentResponseList!=null) {
		return studentResponseList;
		}return null;
}
