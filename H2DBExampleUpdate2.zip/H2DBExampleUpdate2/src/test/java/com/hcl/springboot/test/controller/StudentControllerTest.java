package com.hcl.springboot.test.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotNull;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.beans.BeanUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.hcl.springboot.controller.StudentController;
import com.hcl.springboot.dto.StudentRequestDto;
import com.hcl.springboot.dto.StudentResponseDto;
import com.hcl.springboot.service.IStudentService;

@ExtendWith(MockitoExtension.class)
public class StudentControllerTest {

	@Mock
	IStudentService studentService;

	@InjectMocks
	StudentController studentController;

	StudentRequestDto studentRequestDto;
	StudentRequestDto studentRequestDto2;

	@BeforeEach
	public void setUp() {
		studentRequestDto = new StudentRequestDto();
		studentRequestDto.setName("Anil");
		studentRequestDto.setCourse("java");
		studentRequestDto.setDepartment("CSE");
		studentRequestDto.setEmail("anil@gmail.com");

	}

	@Test
	@DisplayName("Save Student Data : Positive")
	public void saveStudentDataTest_Positive() {
		//given
		when(studentService.saveStudentData(studentRequestDto)).thenReturn(true);
		//when
		ResponseEntity<String> result = studentController.saveStudentData(studentRequestDto);
		//then	
		assertEquals("Data saved succesfully", result.getBody());
		assertEquals(HttpStatus.OK, result.getStatusCode());

	}

	@Test
	@DisplayName("Save Student Data : Negative")
	public void saveStudentDataTest_Negative() {
		//given
		when(studentService.saveStudentData(studentRequestDto)).thenReturn(false);
		//when
		ResponseEntity<String> result = studentController.saveStudentData(studentRequestDto);
		//then
		assertEquals("Data saved Unsuccesfull", result.getBody());
		assertEquals(HttpStatus.NOT_ACCEPTABLE, result.getStatusCode());

	}

	@Test
	@DisplayName("Get Student Details : Positive")
	public void getStudentDetailsTest_Positive() {
		List<StudentResponseDto> studentlist = new ArrayList<StudentResponseDto>();
		StudentResponseDto studentResponseDto = new StudentResponseDto();
		BeanUtils.copyProperties(studentRequestDto, studentResponseDto);
		studentlist.add(studentResponseDto);
		//given
		when(studentService.getStudentDetails()).thenReturn(studentlist);
		//when
		List<StudentResponseDto> studentResponseList = studentController.getStudentDetails();
		//then
		assertNotNull(studentResponseList);
		assertEquals(1, studentResponseList.size());
	}

	@Test
	@DisplayName("Delete Student Details : Positive")
	public void deleteStudentDetailsTest_Positive() {
		//given
		when(studentService.deleteStudentDetails(1)).thenReturn(true);
		//when
		String result = studentController.deleteStudentDetails(1);
		//then
		assertEquals("data deleted successfully", result);
	}

	@Test
	@DisplayName("Delete Student Details : Negative")
	public void deleteStudentDetailsTest_Negative() {
		//given
		when(studentService.deleteStudentDetails(1)).thenReturn(false);
		//when
		String result = studentController.deleteStudentDetails(1);
		//then
		assertEquals("data not deleted", result);
	}

	@Test
	@DisplayName("Update Student Details : Positive")
	public void updateStudentTest_Positive() {
		//given
		when(studentService.updateStudent(1, studentRequestDto)).thenReturn(true);
		//when
		ResponseEntity<String> result = studentController.updateStudent(1, studentRequestDto);
		//then
		assertEquals("Student updated succesfully", result.getBody());
		assertEquals(HttpStatus.OK, result.getStatusCode());

	}

	@Test
	@DisplayName("Update Student Details : Negative")
	public void updateStudentTest_Negative() {
		//given
		when(studentService.updateStudent(1, studentRequestDto)).thenReturn(false);
		//when
		ResponseEntity<String> result = studentController.updateStudent(1, studentRequestDto);
		//then
		assertEquals("Student not updated", result.getBody());
		assertEquals(HttpStatus.NOT_ACCEPTABLE, result.getStatusCode());

	}

}
