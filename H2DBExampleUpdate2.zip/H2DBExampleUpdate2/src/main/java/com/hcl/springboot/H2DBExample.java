package com.hcl.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class H2DBExample {

	public static void main(String[] args) {
		SpringApplication.run(H2DBExample.class, args);
	}

}
