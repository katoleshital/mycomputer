package com.hcl.springboot.service;

import java.util.List;

import com.hcl.springboot.dto.StudentRequestDto;
import com.hcl.springboot.dto.StudentResponseDto;

public interface IStudentService {

	List<StudentResponseDto> getStudentDetails();

	boolean saveStudentData(StudentRequestDto studentRequestDto);

	boolean deleteStudentDetails(int studentId);

	boolean updateStudent(int studentId, StudentRequestDto studentRequestDto);

}