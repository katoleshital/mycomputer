package com.loan.java.service;

import com.loan.java.dto.CustomerRequestDto;
import com.loan.java.dto.LoanProcessDto;
import com.loan.java.dto.LoanResponseDto;
import com.loan.java.exception.CustomerIsNotEligibleForLoanException;
import com.loan.java.exception.VerificationPendingException;

public interface CustomerService {

	boolean addCustomerData(CustomerRequestDto customerRequestDto);

	LoanResponseDto findCustomerDetailById(Integer customerId);

	void evaluationOfDocuments(LoanProcessDto loanProcessDto, Integer customerId);

	LoanResponseDto checkIfTheCustomerIsEligibleForLoanOrNot(Integer customerId)
			throws CustomerIsNotEligibleForLoanException, VerificationPendingException;

}
