package com.loan.java.controller;

import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.loan.java.dto.LoanProcessDto;
import com.loan.java.dto.LoanResponseDto;
import com.loan.java.exception.CustomerIsNotEligibleForLoanException;
import com.loan.java.exception.VerificationPendingException;
import com.loan.java.service.CustomerService;

@RestController
@Validated
public class ApplicationFormController {

	@Autowired
	CustomerService customerService;

	@GetMapping("/customers/{customerId}")
	public ResponseEntity<LoanResponseDto> getCustomerDetailById(
			@NotNull(message = "Book Id can't be Empty") @PathVariable Integer customerId) {
		return new ResponseEntity<LoanResponseDto>(customerService.findCustomerDetailById(customerId),
				HttpStatus.ACCEPTED);
	}

	@PutMapping(value = "/customers/evaluationprocess/{customerId}")
	public String evaluationOfDocuments(@RequestBody LoanProcessDto loanProcessDto, @PathVariable Integer customerId) {
		customerService.evaluationOfDocuments(loanProcessDto, customerId);
		return "Dear Customer your application status got updated......!";
	}

	@GetMapping("/checkeligibility/{customerId}")
	public ResponseEntity<LoanResponseDto> checkIfTheCustomerIsEligibleForLoanOrNot(@PathVariable Integer customerId)
			throws CustomerIsNotEligibleForLoanException, VerificationPendingException {
		return new ResponseEntity<LoanResponseDto>(customerService.checkIfTheCustomerIsEligibleForLoanOrNot(customerId),
				HttpStatus.ACCEPTED);
	}

}