package com.loan.java.exception;

public class CustomerIsNotEligibleForLoanException extends Exception {
	public CustomerIsNotEligibleForLoanException(String message) {
		super(message);
	}
}
