package com.loan.java.exception;

public class VerificationPendingException extends Exception {

	public VerificationPendingException(String message) {
		super(message);
	}

}
