package com.loan.java.service.impl;

import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.loan.java.dto.CustomerRequestDto;
import com.loan.java.dto.LoanProcessDto;
import com.loan.java.dto.LoanResponseDto;
import com.loan.java.entity.Customer;
import com.loan.java.exception.CustomerIsNotEligibleForLoanException;
import com.loan.java.exception.CustomerNotFoundException;
import com.loan.java.exception.VerificationPendingException;
import com.loan.java.repo.CustomerRepository;
import com.loan.java.service.CustomerService;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerRepository customerRepository;

	@Override
	public boolean addCustomerData(CustomerRequestDto customerRequestDto) {
		Customer customer = new Customer();

		BeanUtils.copyProperties(customerRequestDto, customer);
		customer.setStatus("new");
		Customer savedCustomer = customerRepository.save(customer);
		if (savedCustomer != null)
			return true;
		return false;

	}

	@Override
	public LoanResponseDto findCustomerDetailById(Integer customerId) {
		Customer customer = new Customer();
		LoanResponseDto loanResponseDto = new LoanResponseDto();
		Optional<Customer> optionalCustomer = customerRepository.findById(customerId);

		if (optionalCustomer.isPresent()) {
			customer = optionalCustomer.get();
			BeanUtils.copyProperties(customer, loanResponseDto);
			return loanResponseDto;
		} else {
			throw new CustomerNotFoundException("no customer found with th given id:" + customerId);
		}
	}

	@Override
	public void evaluationOfDocuments(LoanProcessDto loanProcessDto, Integer customerId) {
		Customer customer = customerRepository.findById(customerId).get();

		BeanUtils.copyProperties(loanProcessDto, customer);
		customerRepository.save(customer);
	}

	@Override
	public LoanResponseDto checkIfTheCustomerIsEligibleForLoanOrNot(Integer customerId)
			throws CustomerIsNotEligibleForLoanException, VerificationPendingException {
		Customer customer = new Customer();
		LoanResponseDto loanResponseDto = new LoanResponseDto();
		Optional<Customer> optionalCustomer = customerRepository.findById(customerId);

		if (optionalCustomer.isPresent()) {
			customer = optionalCustomer.get();
			BeanUtils.copyProperties(customer, loanResponseDto);
			loanResponseDto.getStatus();
			if (loanResponseDto.getStatus().equalsIgnoreCase("Accept"))
				return loanResponseDto;
			if (loanResponseDto.getStatus().equalsIgnoreCase("new"))
				throw new VerificationPendingException(
						"please wait your verification is pending...your application status is:  "
								+ loanResponseDto.getStatus());
		}
		throw new CustomerIsNotEligibleForLoanException(
				"Dear Customer you are not eligible for the loan please upload correct documents your application status is: "
						+ loanResponseDto.getStatus());
	}

}
