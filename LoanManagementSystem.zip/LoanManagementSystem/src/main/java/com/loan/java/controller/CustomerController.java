package com.loan.java.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.loan.java.dto.CustomerRequestDto;
import com.loan.java.service.CustomerService;

@RestController
@Validated
public class CustomerController {

	@Autowired
	CustomerService customerService;

	@PostMapping("/customers")
	public ResponseEntity<String> addCustomerData(@RequestBody CustomerRequestDto customerRequestDto) {
		boolean response = customerService.addCustomerData(customerRequestDto);
		if (response)
			return new ResponseEntity<String>("Customer Data saved successfully", HttpStatus.ACCEPTED);
		return new ResponseEntity<String>("Customer Data saved successfully", HttpStatus.NOT_ACCEPTABLE);

}
}
