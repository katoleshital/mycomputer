package com.loan.java.exception;

public class PleaseWaitException extends Exception {
	public PleaseWaitException(String message) {
		super(message);
	}
}
