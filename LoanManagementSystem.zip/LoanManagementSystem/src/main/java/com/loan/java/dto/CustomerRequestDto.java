package com.loan.java.dto;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class CustomerRequestDto {
	@NotEmpty(message = "customer name should not be empty")
	private String name;
	@NotEmpty(message = "customer date of birth should not be empty")
	private String dob;
	@NotEmpty(message = "place should not be empty")
	private String place;
	@NotNull(message = "amount should not be null")
	private int loanamount;
	private String status;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public int getLoanamount() {
		return loanamount;
	}

	public void setLoanamount(int loanamount) {
		this.loanamount = loanamount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
