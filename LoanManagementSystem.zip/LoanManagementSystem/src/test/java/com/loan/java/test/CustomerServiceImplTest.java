package com.loan.java.test;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.BeanUtils;

import com.loan.java.dto.CustomerRequestDto;
import com.loan.java.dto.CustomerResponseDto;
import com.loan.java.entity.Customer;
import com.loan.java.repo.CustomerRepository;
import com.loan.java.service.impl.CustomerServiceImpl;

@ExtendWith(MockitoExtension.class)
public class CustomerServiceImplTest {
	@Mock
	CustomerRepository customerRepository;

	@InjectMocks
	CustomerServiceImpl customerServiceImpl;

	Customer customer;
	CustomerRequestDto customerRequestDto;
	CustomerResponseDto customerResponseDto;

	Customer savedCustomer;

	@BeforeEach
	public void setUp() {
		customerRequestDto = new CustomerRequestDto();
		customerRequestDto.setName("surbhi");
		customerRequestDto.setDob("23/7/1998");
		customerRequestDto.setPlace("pune");
		customerRequestDto.setLoanamount(23400);
		customerRequestDto.setStatus("new");

		customer = new Customer();
		customer.setCustomerId(1);
		customer.setName("surbhi");
		customer.setDob("23/7/1998");
		customer.setLoanamount(23400);
		customer.setPlace("pune");
		customer.setStatus("new");

		savedCustomer = new Customer();
		BeanUtils.copyProperties(customer, savedCustomer);

	}

	@Test

	@DisplayName("add Customer Data:Positive")
	public void addCustomerDataTest_Positive() {

		// context

		when(customerRepository.save(any(Customer.class))).thenReturn(savedCustomer);

		// event
		boolean result = customerServiceImpl.addCustomerData(customerRequestDto);

		// outcome
		assertTrue(result);

	}

}
