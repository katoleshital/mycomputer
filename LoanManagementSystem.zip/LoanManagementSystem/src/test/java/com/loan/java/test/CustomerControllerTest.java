package com.loan.java.test;

import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.BeanUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.loan.java.controller.ApplicationFormController;
import com.loan.java.controller.CustomerController;
import com.loan.java.dto.CustomerRequestDto;
import com.loan.java.dto.CustomerResponseDto;
import com.loan.java.dto.LoanResponseDto;
import com.loan.java.entity.Customer;
import com.loan.java.exception.CustomerNotFoundException;
import com.loan.java.service.CustomerService;

@ExtendWith(MockitoExtension.class)
public class CustomerControllerTest {
	@Mock
	CustomerService customerService;

	@InjectMocks
	CustomerController customerController;

	@InjectMocks
	ApplicationFormController applicationFormController;

	CustomerRequestDto customerRequestDto;
	Customer customer;
	LoanResponseDto loanResponseDto;
	CustomerResponseDto customerResponseDto;
	List<CustomerResponseDto> customerResponseDtolist;

	@BeforeEach
	public void setUp() {
		customerRequestDto = new CustomerRequestDto();
		customerRequestDto.setName("shital");
		;
		customerRequestDto.setDob("23/11/1998");
		customerRequestDto.setPlace("nagpur");
		customerRequestDto.setLoanamount(56000);
		;
		customerRequestDto.setStatus("new");
		;

		customer = new Customer();
		customer.setCustomerId(1);
		customer.setName("shital");
		;
		customer.setDob("23/11/1998");
		customer.setLoanamount(56000);
		;
		customer.setPlace("nagpur");
		;
		customer.setStatus("new");
		;

		customerResponseDto = new CustomerResponseDto();
		BeanUtils.copyProperties(customer, customerResponseDto);
		loanResponseDto = new LoanResponseDto();
		BeanUtils.copyProperties(customer, loanResponseDto);

		customerResponseDtolist = new ArrayList<>();
		customerResponseDtolist.add(customerResponseDto);

	}

	@Test

	@DisplayName("Add Customer Data_Positive")
	public void addCustomerDataTest_Positive() {
		// context
		when(customerService.addCustomerData(customerRequestDto)).thenReturn(true);

		// event
		ResponseEntity<String> result = customerController.addCustomerData(customerRequestDto);

		// outcome
		assertEquals("Customer Data saved successfully", result.getBody());
		assertEquals(HttpStatus.ACCEPTED, result.getStatusCode());
	}

	@Test

	@DisplayName("Add Customer Data_Negative")
	public void addCustomerDataTest_Negative() {
		// context
		when(customerService.addCustomerData(customerRequestDto)).thenReturn(false);

		// event
		ResponseEntity<String> result = customerController.addCustomerData(customerRequestDto);

		// outcome
		assertEquals("Customer Data saved successfully", result.getBody());
		assertEquals(HttpStatus.NOT_ACCEPTABLE, result.getStatusCode());
	}

	@Test
	@DisplayName("Find Customer by Id :Positive")
	public void getCustomerDetailByIdTest_Positive() {

		// context
		when(customerService.findCustomerDetailById(1)).thenReturn(loanResponseDto);

		// event
		ResponseEntity<LoanResponseDto> result = applicationFormController.getCustomerDetailById(1);

		assertEquals(loanResponseDto, result.getBody());
		verify(customerService).findCustomerDetailById(1);

	}

	@Test
	@DisplayName("Find Customer by Id  :Negative")
	public void getCustomerDetailByIdTest_Negative() {

		// context
		when(customerService.findCustomerDetailById(10))
				.thenThrow(new CustomerNotFoundException("Customer Id Does not Exist"));

		// event
		Exception e = assertThrows(CustomerNotFoundException.class, () -> {
			applicationFormController.getCustomerDetailById(10);
		});
		assertEquals("Customer Id Does not Exist", e.getMessage());

		verify(customerService).findCustomerDetailById(10);
	}

}
