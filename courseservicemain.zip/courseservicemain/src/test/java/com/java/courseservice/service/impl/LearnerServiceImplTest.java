package com.java.courseservice.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.java.courseservice.dto.CourseRequestDto;
import com.java.courseservice.dto.CourseResponseDto;
import com.java.courseservice.entity.Course;
import com.java.courseservice.exception.CourseNotFoundException;
import com.java.courseservice.repo.CourseRepository;
import com.java.courseservice.service.Impl.LearnerServiceImpl;

@ExtendWith(MockitoExtension.class)
public class LearnerServiceImplTest {

	@Mock
	CourseRepository courseRepository;

	@InjectMocks
	LearnerServiceImpl learnerServiceImpl;

	CourseRequestDto courseRequestDto;
	Course course;
	Course course2;
	Course savedCourse;
	Iterator<Course> course1;
	Optional<Course> opCourse;

	CourseResponseDto courseResponseDto;
	List<CourseResponseDto> courseResponseDtolist;

	@BeforeEach
	public void setUp() {

		courseRequestDto = new CourseRequestDto();
		courseRequestDto.setCourseName("Web-development");
		courseRequestDto.setPrice(4000d);
		courseRequestDto.setUserId(1);

		Course course = new Course();
		course.setCourseId(101);
		course.setCourseName("Web-development");
		course.setPrice(4000d);
		course.setUserId(1);

		course2 = new Course();
		course2.setCourseId(102);
		course2.setCourseName("Machine Learning");
		course2.setPrice(3000d);
		course2.setUserId(2);

		savedCourse = new Course();
		savedCourse.setCourseId(101);
		savedCourse.setCourseName("Web-development");
		savedCourse.setPrice(4000d);
		savedCourse.setUserId(1);

		courseResponseDto = new CourseResponseDto();
		courseResponseDtolist = new ArrayList<>();
		courseResponseDtolist.add(courseResponseDto);

		opCourse = opCourse.of(course);
	}

	@Test
	@DisplayName("view All courses:Positive")
	public void viewCoursesTest_Positive() {
		List<Course> courses = new ArrayList();
		courses.add(course2);
		courses.add(savedCourse);
// context
		when(courseRepository.findAll()).thenReturn(courses);
// event
		List<CourseResponseDto> courseResponseDtolist = learnerServiceImpl.viewCourses();
// outcome
		assertNotNull(courseResponseDtolist);
		assertEquals(2, courseResponseDtolist.size());
	}

	@Test
	@DisplayName("view All courses:Negative")
	public void viewCoursesTest_Negative() {
		List<Course> courses = new ArrayList();
//context
		when(courseRepository.findAll()).thenReturn(courses);
//event
		List<CourseResponseDto> courseResponseDtolist = learnerServiceImpl.viewCourses();
//outcome
		assertTrue(courseResponseDtolist.isEmpty());
	}

	@Test
	@DisplayName("view Course By Course Name :Positive")
	public void searchCourseByCourseName() throws CourseNotFoundException {
// context
		when(courseRepository.findByCourseNameContaining("Web-development")).thenReturn((opCourse));
// event
		CourseResponseDto result = learnerServiceImpl.searchCourseByCourseName("Web-development");
// outcome
		assertEquals("Web-development", result.getCourseName());
	}

	@Test
	@DisplayName("view Course By Course Name:Negative")
	public void searchCourseByCourseName_Negative() {
// context
		when(courseRepository.findByCourseNameContaining("JAVA")).thenReturn(null);
//event
		NullPointerException e = assertThrows(NullPointerException.class, () -> {
			learnerServiceImpl.searchCourseByCourseName("JAVA");
		});
// outcome
		assertEquals(NullPointerException.class, e.getClass());
	}

	@Test
	@DisplayName("view Course By Id Test:Positive")
	public void viewCourseByCourseId() throws CourseNotFoundException {
// context
		when(courseRepository.findById(101)).thenReturn(opCourse);
// event
		CourseResponseDto result = learnerServiceImpl.viewCourseByCourseId(101);
// outcome
		assertEquals("Web-development", result.getCourseName());
	}

	@Test
	@DisplayName("View Course By Id Test:Negative")
	public void viewCourseByCourseIdTest_Negative() {
// context
		when(courseRepository.findById(101)).thenReturn(null);
//event
		NullPointerException e = assertThrows(NullPointerException.class, () -> {
			learnerServiceImpl.viewCourseByCourseId(101);
		});
// outcome
		assertEquals(NullPointerException.class, e.getClass());
	}
}