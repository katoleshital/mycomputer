package com.java.courseservice.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import com.java.courseservice.dto.CourseRequestDto;
import com.java.courseservice.dto.CourseResponseDto;
import com.java.courseservice.entity.Course;
import com.java.courseservice.exception.CourseNotFoundException;
import com.java.courseservice.service.LearnerService;

@ExtendWith(MockitoExtension.class)
public class LearnerControllerTest {

	@Mock
	LearnerService learnerService;

	@InjectMocks
	LearnerController learnerController;

	CourseRequestDto courseRequestDto;
	Course course;

	CourseResponseDto courseResponseDto;
	List<CourseResponseDto> courseResponseDtolist;

	@BeforeEach
	public void setUp() {

		courseRequestDto = new CourseRequestDto();
		courseRequestDto.setCourseName("Web-development");
		courseRequestDto.setPrice(4000d);

		Course course = new Course();
		course.setCourseId(101);
		course.setCourseName("Web-development");
		course.setPrice(4000d);
		course.setUserId(1);

		courseResponseDto = new CourseResponseDto();

		courseResponseDtolist = new ArrayList<>();
		courseResponseDtolist.add(courseResponseDto);

	}

	@Test
	@DisplayName("View All Course :Positive")
	public void viewCourses_Positive() {

		// context
		when(learnerService.viewCourses()).thenReturn(courseResponseDtolist);

		// event
		ResponseEntity<List<CourseResponseDto>> result = learnerController.viewCourses();

		// outcome
		assertEquals(1, result.getBody().size());
	}

	@Test
	@DisplayName("View All Course :Negative")
	public void viewCourses_Negative() {

		// context
		when(learnerService.viewCourses()).thenReturn(null);

		// event
		ResponseEntity<List<CourseResponseDto>> result = learnerController.viewCourses();

		// outcome
		assertEquals(200, result.getStatusCodeValue());

	}

	@Test
	@DisplayName("Search Course by Name :Positive")
	public void searchCourseByCourseName_Positive() throws CourseNotFoundException {

		// context
		when(learnerService.searchCourseByCourseName("Web-development")).thenReturn(courseResponseDto);

		// event
		ResponseEntity<CourseResponseDto> result = learnerController.searchCourseByCourseName("Web-development");

		assertEquals(courseResponseDto, result.getBody());
		verify(learnerService).searchCourseByCourseName("Web-development");

	}

	@Test
	@DisplayName("Search Course by Name :Negative")
	public void searchCourseByCourseName_Negative() throws CourseNotFoundException {
		// context
		when(learnerService.searchCourseByCourseName("JAVA"))
				.thenThrow(new CourseNotFoundException("course not found with the given name:"));
		// event
		Exception e = assertThrows(CourseNotFoundException.class, () -> {
			learnerController.searchCourseByCourseName("JAVA");
		});
		assertEquals("course not found with the given name:", e.getMessage());
		verify(learnerService).searchCourseByCourseName("JAVA");
	}

	@Test
	@DisplayName("view Course By CourseId :Positive")
	public void viewCourseByCourseId_Positive() throws CourseNotFoundException {

		// context
		when(learnerService.viewCourseByCourseId(101)).thenReturn(courseResponseDto);

		// event
		CourseResponseDto result = learnerController.viewCourseByCourseId(101);

		assertEquals(courseResponseDto, result);
		verify(learnerService).viewCourseByCourseId(101);
	}

	@Test
	@DisplayName("view Course By CourseId :Negative")
	public void viewCourseByCourseId_Negative() throws CourseNotFoundException {
		// context
		when(learnerService.viewCourseByCourseId(201))
				.thenThrow(new CourseNotFoundException("Course id Does not Exist"));

		// event
		Exception e = assertThrows(CourseNotFoundException.class, () -> {
			learnerController.viewCourseByCourseId(201);
		});

		assertEquals("Course id Does not Exist", e.getMessage());
		verify(learnerService).viewCourseByCourseId(201);
	}

}