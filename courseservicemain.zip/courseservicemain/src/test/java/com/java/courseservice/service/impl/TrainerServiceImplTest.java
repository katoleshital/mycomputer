package com.java.courseservice.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.BeanUtils;
import org.springframework.http.ResponseEntity;

import com.java.courseservice.dto.CourseRequestDto;
import com.java.courseservice.dto.CourseResponseDto;
import com.java.courseservice.entity.Course;
import com.java.courseservice.repo.CourseRepository;
import com.java.courseservice.service.Impl.TrainerServiceImpl;

@ExtendWith(MockitoExtension.class)
public class TrainerServiceImplTest {
	@Mock
	CourseRepository courseRepository;

	@InjectMocks
	TrainerServiceImpl trainerServiceImpl;

	Course course;
	CourseRequestDto courseRequestDto;
	CourseResponseDto courseResponseDto;

	Course createdCourse;

	@BeforeEach
	public void setUp() {
		course = new Course();
		course.setCourseId(101);
		course.setCourseName("java");
		course.setPrice(3400d);
		course.setUserId(1);

		courseRequestDto = new CourseRequestDto();
		courseRequestDto.setCourseName("java");
		courseRequestDto.setPrice(3400d);
		courseRequestDto.setUserId(1);

		createdCourse = new Course();
		BeanUtils.copyProperties(course, createdCourse);
	}

	@Test
	@DisplayName("Save Book Data:Positive")
	public void addCoursesTest_Positive() {

		// context

		when(courseRepository.save(course)).thenReturn(createdCourse);

		// event
		String result = trainerServiceImpl.addCourse(courseRequestDto, 1);

		// outcome
		assertEquals(createdCourse.getCourseId(), result);

	}
}