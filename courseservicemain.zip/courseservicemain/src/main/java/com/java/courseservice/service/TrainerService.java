package com.java.courseservice.service;

import javax.validation.Valid;

import com.java.courseservice.dto.CourseRequestDto;

public interface TrainerService {

	String addCourse(@Valid CourseRequestDto courseRequestDto, Integer userId);

	String editCourse(@Valid CourseRequestDto courseRequestDto, Integer courseId, Integer userId);

}
