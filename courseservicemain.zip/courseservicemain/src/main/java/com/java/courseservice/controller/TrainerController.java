package com.java.courseservice.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.java.courseservice.dto.CourseRequestDto;
import com.java.courseservice.service.TrainerService;

@RestController
public class TrainerController {

	private final Logger Log = LoggerFactory.getLogger(this.getClass());

	@Autowired
	TrainerService trainerService;

	@PostMapping("/courses")
	public ResponseEntity<String> addCourse(@Valid @RequestBody CourseRequestDto courseRequestDto,
			@RequestParam Integer userId) {
		Log.info("Inside method addcourse");
		String response = trainerService.addCourse(courseRequestDto, userId);
		Log.info("the response received by addcourse method is " + response);
		return new ResponseEntity<String>(response, HttpStatus.CREATED);
	}

	// Api for updation of courses
	@PutMapping("/courses/editCourse")
	public ResponseEntity<String> editCourse(@Valid @RequestBody CourseRequestDto courseRequestDto,
			@RequestParam Integer courseId, @RequestParam Integer userId) {
		String response = trainerService.editCourse(courseRequestDto, courseId, userId);
		return new ResponseEntity<String>(response, HttpStatus.OK);
	}
}
