package com.foodapp.java;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MenuserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
