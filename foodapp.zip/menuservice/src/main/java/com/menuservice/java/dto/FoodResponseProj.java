package com.menuservice.java.dto;

public interface FoodResponseProj {
	public Integer getFoodId();

	public String getFoodName();

	public double getPrice();
}
