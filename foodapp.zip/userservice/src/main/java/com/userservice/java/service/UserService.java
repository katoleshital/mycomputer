package com.userservice.java.service;

import com.userservice.java.entity.User;

public interface UserService {

	void registerUser(User user);

}
