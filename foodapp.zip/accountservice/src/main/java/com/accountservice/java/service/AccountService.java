package com.accountservice.java.service;

public interface AccountService {

}
