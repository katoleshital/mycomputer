package com.java.buyservice.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.java.buyservice.dto.CourseResponseDto;
import com.java.buyservice.exception.CourseNotFoundException;

@FeignClient(name = "courseservice")
public interface CourseServiceClient {

	// Getting course by passing courseId from COURSESERVICE

	/*
	 * @GetMapping("/course") public Course viewCourseByCourseId(@RequestParam
	 * Integer courseId);
	 */

	@GetMapping("/course")
	public CourseResponseDto viewCourseByCourseId(@RequestParam Integer courseId) throws CourseNotFoundException;

}
