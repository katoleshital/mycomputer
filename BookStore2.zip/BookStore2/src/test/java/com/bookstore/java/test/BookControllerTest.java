package com.bookstore.java.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.BeanUtils;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.bookstore.java.controller.BookController;
import com.bookstore.java.dto.BookRequestDto;
import com.bookstore.java.dto.BookResponseDto;
import com.bookstore.java.entity.Book;
import com.bookstore.java.exception.BookNotFoundException;
import com.bookstore.java.service.BookService;

@WebMvcTest
public class BookControllerTest {
	@Mock
	BookService bookService;
	
	@InjectMocks
	BookController bookController;
	
	BookRequestDto bookRequestDto;
	Book book;
	
	BookResponseDto bookResponseDto;
	List<BookResponseDto> bookResponseDtolist;

	
	@BeforeEach
	public void setUp() {
		bookRequestDto=new BookRequestDto();
		bookRequestDto.setBookName("Complete Referance Java");
		bookRequestDto.setAuthor("Herbert Schildt");
		bookRequestDto.setGenre("Educational");
		bookRequestDto.setPrice(500);
		bookRequestDto.setRating(4);
		
		book = new Book();
		book.setBookId(1);;
		book.setBookName("C Programming");
		book.setAuthor("Yashwant Kanedkar");
		book.setGenre("Educational");
		book.setPrice(500);
		book.setRating(4);

		
		bookResponseDto = new BookResponseDto();
		BeanUtils.copyProperties(book, bookResponseDto);
		
		bookResponseDtolist = new ArrayList<>();
		bookResponseDtolist.add(bookResponseDto);

	}
	
	@Test
	@DisplayName("Save Book Data_Positive")
	public void addBookTest_Positive() {
		//context
		when(bookService.addBook(bookRequestDto)).thenReturn(true);		
	
		//event
		ResponseEntity<String> result=bookController.addBook(bookRequestDto);

		//outcome
		assertEquals("Book Data saved successfully",result.getBody());
		assertEquals(HttpStatus.ACCEPTED,result.getStatusCode());
	}
	
	@Test
	@DisplayName("Save Book Data_Negative")
	public void addBookTest_Negative() {
		//context
		when(bookService.addBook(bookRequestDto)).thenReturn(false);		
	
		//event
		ResponseEntity<String> result=bookController.addBook(bookRequestDto);

		//outcome
		assertEquals("Book Data saved successfully",result.getBody());
		assertEquals(HttpStatus.NOT_ACCEPTABLE,result.getStatusCode());
	}

	
	@Test
	@DisplayName("Get All Book :Positive")
	public void getAllCustomers_Positive() {

		// context
		when(bookService.getAllBooks()).thenReturn(bookResponseDtolist);

		// event
		ResponseEntity<List<BookResponseDto>> result = bookController.getAllBooks();

		// outcome
		assertEquals(1, result.getBody().size());

	}

	@Test
	@DisplayName("Get All Book :Negative")
	public void getAllBook_Negative() {

		// context
		when(bookService.getAllBooks()).thenReturn(null);

		// event
		ResponseEntity<List<BookResponseDto>> result = bookController.getAllBooks();

		// outcome
		assertEquals(200, result.getStatusCodeValue());
	}
	
	@Test
	@DisplayName("Find Book by Id :Positive")
	public void getBookByIdTest_Positive(){

		// context
		when(bookService.getBookById(1)).thenReturn(bookResponseDto);
		
		// event
		ResponseEntity<BookResponseDto> result = bookController.getBookById(1);

		assertEquals(bookResponseDto, result.getBody());
		verify(bookService).getBookById(1);

	}
	
	@Test
	@DisplayName("Find Book by Id :Negative")
	public void getBookByIdTestTest_Negative() {

		// context
		when(bookService.getBookById(100)).thenThrow(new BookNotFoundException("Book Id Does not Exist"));

		// event
		Exception e = assertThrows(BookNotFoundException.class, () -> {
			bookController.getBookById(100);
		});
		assertEquals("Book Id Does not Exist", e.getMessage());

		verify(bookService).getBookById(100);
	}

}


}
