package com.pattern.java;

//An Implementation to perform START/ON Action
public class ACStartState implements State {

	@Override
	public void doAction() {
		System.out.println("AC is turned ON");
	}

}
