package com.pattern.java;

/*This Context class performed Action
based on state */

public class ACContext implements State {
	private State state;

	public void setState(State state) {
		this.state = state;
	}

	public State getState() {
		return state;
	}

	@Override
	public void doAction() {
		state.doAction();
	}
}
