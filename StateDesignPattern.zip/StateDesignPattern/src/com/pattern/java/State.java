package com.pattern.java;

//Contract to represent state 

public interface State {
	public abstract void doAction();
}
