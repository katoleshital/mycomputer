package com.menuservice.java.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.menuservice.java.dto.FoodResponseProj;
import com.menuservice.java.entity.Menu;
import com.menuservice.java.exception.FoodItemNotFoundException;
import com.menuservice.java.repo.MenuRepository;

@Service
public class MenuService implements IMenuService {
	@Autowired
	MenuRepository menuRepository;
	@Autowired
	private MenuRepository repository;

	@Override
	public List<FoodResponseProj> getFoodItemByName(String foodName) {
		List<FoodResponseProj> foodResponseProjList = menuRepository.findByFoodNameContaining(foodName);
		if (foodResponseProjList.isEmpty())
			throw new FoodItemNotFoundException("no fooditem present with given name: " + foodName);
		return foodResponseProjList;

	}

	@Override
	public List<Menu> findPaginated(int pageNo, int pageSize) {
		Pageable paging = PageRequest.of(pageNo, pageSize);
		Page<Menu> pagedResult = repository.findAll(paging);
		return pagedResult.toList();
	}

	@Override
	public Boolean getFoodItemById(Integer foodId) {
		Optional<Menu> response = menuRepository.findById(foodId);
		System.out.println(foodId);
		if (response.isPresent()) {
			return true;
		} else
			return false;
	}
}
